<?php
	require_once './99dou.php';

	$_99dou = new _99douInterface();

	$array = array();
	foreach($_POST   as   $key   =>   $value)   { 
		$array[$key] = $value;
	} 
	
	$msg = "";
	$success_qty = 0;
	$fail_qty = 0;
	$out_trade_id = "";

	$r = $_99dou->VerifyNotify($array, $out_trade_id, $success_qty, $fail_qty, $msg);

    if (r == 0) // �ɹ���֤����
    {
            
		///TODO : ����״̬������

		echo "OK";
    }
    else
    {
		echo "ERROR|" + msg ;
    }

?>