<?php
	require_once './99dou.php';

	$_99dou = new _99douInterface();

	$out_trade_id = uniqid(mt_rand(), true);
	
	$msg = "";

	$result = $_99dou->Direct($out_trade_id,'10316', 1,"1549332002","",$_SERVER["REMOTE_ADDR"],5,$msg);

	echo "直充返回:".$result." 消息：".$msg."<br/>";

	$success_qty=0;
	$fail_qty=0;

	$result = $_99dou->Query($out_trade_id,$success_qty,$fail_qty,$msg);

	echo "查询返回:".$result." ;消息：".$msg.";success_qty:".$success_qty.";fail_qty:".$fail_qty;
?>